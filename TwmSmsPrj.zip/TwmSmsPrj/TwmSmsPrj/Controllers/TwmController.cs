﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using TwmSmsPrj.Models;

namespace TwmSmsPrj.Controllers
{
    
    public class TwmController : Controller
    {
        private readonly ILogger<TwmController> _logger;

        public TwmController(ILogger<TwmController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet("/Twm/Privacy")]
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpPost("/Twm/Index")]
        //[ValidateAntiForgeryToken]
        public ActionResult Index(Identity identity)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    return View(identity);
                }
                else
                {


                    //var ModelStateErrors = _requestService.GetModelStateErrors("IdentityAsync", ModelState);
                    //if (ModelStateErrors.ContainsKey("AccountIdHidden"))
                    //    ModelState.AddModelError("AccountId", ModelStateErrors.FirstOrDefault(e => e.Key == "AccountIdHidden").Value.FirstOrDefault());

                    //return View(identity);
                    return RedirectToAction("Index");


                    //return Redirect("https://www.fubon.com");
                }
            }
            catch (Exception ex)
            {
                return Redirect("https://www.fubon.com/insuranceagency/home/index.htm");
            }
        }

    }
}