﻿using Microsoft.AspNetCore.Mvc;

namespace TwmSmsPrj.Controllers
{
    [ApiController]    
    [Route("Field[controller]")]
    public class ValidationController : ControllerBase
    {
        [HttpGet]
        [Route("Hello")]
        public IActionResult Hello(string name)
        {
            return Ok(new { name = name });
        }

        [HttpPost]
        [Route("Validate")]
        public IActionResult ValidateField([FromBody] DATA dt)
        {
            try
            {
                bool isValid = false;
                if (dt.fieldName == "CustName")
                {
                    if (!string.IsNullOrEmpty(dt.fieldValue))
                    {
                        isValid = true;
                    }
                    return Ok(new { isValid });
                }
                else
                {
                    isValid = true;
                    return Ok(new { isValid });
                }

            }
            catch (Exception ex)
            {
                return new BadRequestResult();
            }
        }
    }

    public class DATA
    {
        public string fieldName { get; set; }
        public string fieldValue { get; set; }
    }
}
