﻿using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Globalization;
using System.Text.RegularExpressions;

namespace TwmSmsPrj.Models
{
    class DateOfBirthAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            try
            {
                var dateString = value as string;
                if (string.IsNullOrWhiteSpace(dateString)) return false;
                DateTime dt;
                if (DateTime.TryParseExact(dateString, "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out dt)
                    && dt > new DateTime(1901,01,01) && dt < DateTime.Now)
                    return IsValid(dt);
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }
        private bool IsValid(DateTime dateTime) {
            if (dateTime.Year < 1753) return false;
            return true;
        }
    }

    class TaiwanIdNumberAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var logger = (ILogger)validationContext.GetService(typeof(ILogger));
            try
            {
                var dateString = value as string;
                if (string.IsNullOrWhiteSpace(dateString)) return new ValidationResult("不可為空值");

                if (IsValidCitizenId(dateString)) return ValidationResult.Success;
                if (IsValidForeignerId(dateString)) return ValidationResult.Success;

                return new ValidationResult("請輸入正確身分證字號/居留證號碼");
            }
            catch (Exception ex)
            {
                logger.LogError(null, ex);
                return new ValidationResult("系統驗證錯誤");
            }
        }

        public bool IsValidCitizenId(string idNumber)
        {
            var re = new Regex(@"^[a-zA-Z][12]\d{8}$", RegexOptions.Compiled);
            if (re.IsMatch(idNumber))
            {
                var asNumber = REGION_TO_NUMBER[idNumber.Substring(0, 1).ToUpper()[0] - 'A'] + idNumber.Substring(1, 8);
                var sum = asNumber.Reverse().Take(9).Select((n, i) => (int)Char.GetNumericValue(n) * (i + 1)).Sum() + (int)Char.GetNumericValue(asNumber[0]);
                var checksum = (10 - (sum % 10)) % 10;
                return checksum == (int)Char.GetNumericValue(idNumber, 9);
            }
            return false;
        }

        public bool IsValidForeignerId(string idNumber)
        {
            var re = new Regex(@"^[a-zA-Z][a-dA-D]\d{8}", RegexOptions.Compiled);
            if (re.IsMatch(idNumber))
            {
                var regionGender = idNumber.Substring(0, 2).ToUpper();
                var asNumber = REGION_TO_NUMBER[regionGender[0] - 'A'] + GENDER_TO_NUMBER[regionGender[1] - 'A'] + idNumber.Substring(2);
                return Checksum(idNumber, asNumber);
            }
            var reNew = new Regex(@"^[a-zA-Z][89]\d{8}", RegexOptions.Compiled);
            if (reNew.IsMatch(idNumber))
            {
                var regionGender = idNumber.Substring(0, 1).ToUpper();
                var asNumber = REGION_TO_NUMBER[regionGender[0] - 'A'] + idNumber.Substring(1);
                return Checksum(idNumber, asNumber);
            }
            return false;
        }

        private static bool Checksum(string idNumber, string asNumber)
        {
            var checksum = (10 - (asNumber.Select(n => (int)Char.GetNumericValue(n)).Zip(MUL, (n, m) => n * m % 10).Sum() % 10)) % 10;
            return checksum == Char.GetNumericValue(idNumber, 9);
        }

        private static string[] REGION_TO_NUMBER = new[]
{
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "34",
            "18",
            "19",
            "20",
            "21",
            "22",
            "35",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "32",
            "30",
            "31",
            "33"
        };
        private static string[] GENDER_TO_NUMBER = { "0", "1", "2", "3" };

        private static int[] MUL = { 1, 9, 8, 7, 6, 5, 4, 3, 2, 1 };

    }


}
