﻿using System.ComponentModel.DataAnnotations;

namespace TwmSmsPrj.Models
{
    public class Identity
    {
        [Display(Name = "姓名")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "請輸入姓名")]         
        public string CustName { get; set; }

        [Display(Name = "身分證字號")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "請輸入正確格式之身分證字號")]
        [RegularExpression(@"\w{10}", ErrorMessage = "請輸入正確格式之身分證字號")]
        [TaiwanIdNumber()]
        public string Idno { get; set; }
    }
}
