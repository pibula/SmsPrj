﻿$(document).ready(function () {
    //setBackgroundCss();
    //collapseToggle();
    ////var checkbox_custom = document.querySelectorAll('.checkbox_custom');
    ////if (checkbox_custom) checkbox_custom.forEach(element => element.checked = true);
    //toggleEyeMaskId();

    //alert("ohio~gojai imas!");


    $('input[name="CustName"]').on('blur', function () {
        var fieldName = 'CustName';
        var fieldValue = $(this).val();
        //var dd = { fieldName: fieldName, fieldValue: fieldValue };
        //var dd = {fieldName: fieldName, fieldValue: fieldValue };
        //var d = JSON.stringify(dd);
        var d = JSON.stringify({
            fieldName: 'CustName',
            fieldValue: $(this).val()
        });

        var dd = JSON.stringify({
            fieldName: fieldName,
            fieldValue: fieldValue
        });

        $.ajax({
            //typw: "GET",
            //url: 'http://localhost/SmsApi/Validation/Hello?name=yyyyy',
            //async: false,

            type: "POST",                       
            url: '/Sms/FieldValidation/Validate',
            contentType: "application/json",
            dataType: "json",
            data: dd,
            success: function (result) {
                if (!result.isValid) {
                    alert('Validation failed');
                }
                else {
                    alert("yes");
                }
            },
            error: function (errormsg) {
                alert("error:");
                alert(errormsg);
            },
        }).done(function () {
            alert("Done!");
        });
        //alert("hi, " + value);
    });


});

function identitySubmit(event) {
    event.preventDefault()
    //alert("dm");
    //return;
    //if (!identityValidate()) return;
    //if (!identityValidate()) { return; }
    document.getElementById('IdentityBtn').disabled = true;
    document.getElementById('Identity').submit();
}

function identityValidate() {
    var AccountId = document.getElementById("AccountIdHidden").value;
    var MobileNumber = document.getElementById("MobileNumber").value;

    if ((!AccountId && !MobileNumber)
        || (!checkTwID(AccountId) && !checkMobile(MobileNumber))) {
        alert("請您填寫身分證字號及行動電話，以繼續進行下一步，謝謝!");
        return false;
    }
    if (!checkTwID(AccountId)) {
        alert("請輸入正確格式之身分證字號");
        return false;
    }
    if (document.getElementById("").value == "") {
        alert("請輸入正確格式之手機號碼");
        return false;
    }

    return true;
}